package fr.snowglobe.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Importe l'image fournie par l'utilisateur (copie locale -> fonctionne hors ligne),
 * puis la prépare une seule fois : orientation EXIF, réduction, recadrage des marges
 * transparentes, couleur sélective (fleurs en couleur, reste en niveaux de gris)
 * et extraction d'une palette pour colorer les pétales.
 */
object SceneImage {

    class Loaded(val bitmap: Bitmap, val palette: IntArray)

    val DEFAULT_PALETTE = intArrayOf(
        0xFFE53935.toInt(), 0xFFF06292.toInt(), 0xFFFFCA28.toInt(), 0xFFFF7043.toInt(),
        0xFF7CB342.toInt(), 0xFF42A5F5.toInt(), 0xFFAB47BC.toInt(),
    )

    fun file(ctx: Context) = File(ctx.filesDir, "scene_image")

    fun exists(ctx: Context) = file(ctx).exists()

    /** Copie l'image choisie dans le stockage privé de l'application. */
    fun import(ctx: Context, uri: Uri): Boolean {
        val target = file(ctx)
        val tmp = File(ctx.filesDir, "scene_image.tmp")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { input.copyTo(it) }
            } ?: return false
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(tmp.path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) {
                tmp.delete(); false
            } else {
                tmp.renameTo(target)
            }
        } catch (e: Exception) {
            tmp.delete(); false
        }
    }

    fun load(ctx: Context, maxSize: Int, selective: Boolean, threshold: Float): Loaded? {
        val f = file(ctx)
        if (!f.exists()) return null

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSize) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp = BitmapFactory.decodeFile(f.path, opts) ?: return null

        // Orientation EXIF (photos prises au téléphone)
        val degrees = try {
            when (ExifInterface(f.path).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) { 0f }

        val scale = min(1f, maxSize.toFloat() / max(bmp.width, bmp.height))
        if (degrees != 0f || scale < 1f) {
            val m = Matrix().apply { postScale(scale, scale); postRotate(degrees) }
            val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (t !== bmp) bmp.recycle()
            bmp = t
        }
        if (!bmp.isMutable || bmp.config != Bitmap.Config.ARGB_8888) {
            val t = bmp.copy(Bitmap.Config.ARGB_8888, true)
            bmp.recycle()
            bmp = t
        }
        return process(bmp, selective, threshold)
    }

    private fun process(bmp: Bitmap, selective: Boolean, threshold: Float): Loaded {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        val rnd = Random(42)
        val samples = ArrayList<Int>()
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        val lo = threshold - 0.08f
        val hi = threshold + 0.08f

        for (yy in 0 until h) {
            val row = yy * w
            for (xx in 0 until w) {
                val i = row + xx
                val c = px[i]
                val a = c ushr 24
                if (a < 16) continue
                if (xx < minX) minX = xx
                if (xx > maxX) maxX = xx
                if (yy < minY) minY = yy
                if (yy > maxY) maxY = yy

                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                val v = mx / 255f
                val colorness = smooth(lo, hi, sat) * smooth(0.12f, 0.25f, v)

                if (colorness > 0.9f && samples.size < 4000 && rnd.nextInt(48) == 0) samples.add(c)
                if (selective && colorness < 1f) {
                    val lum = 0.299f * r + 0.587f * g + 0.114f * b
                    val nr = (lum + (r - lum) * colorness).toInt().coerceIn(0, 255)
                    val ng = (lum + (g - lum) * colorness).toInt().coerceIn(0, 255)
                    val nb = (lum + (b - lum) * colorness).toInt().coerceIn(0, 255)
                    px[i] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)

        // Recadre les marges transparentes : les pieds du personnage se posent bien sur la neige.
        var out = bmp
        if (maxX >= 0 && (minX > 2 || minY > 2 || maxX < w - 3 || maxY < h - 3)) {
            out = Bitmap.createBitmap(bmp, minX, minY, maxX - minX + 1, maxY - minY + 1)
            if (out !== bmp) bmp.recycle()
        }

        val palette = if (samples.size >= 8) {
            samples.shuffle(rnd)
            IntArray(8) { samples[it] or 0xFF000000.toInt() }
        } else DEFAULT_PALETTE
        return Loaded(out, palette)
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}
