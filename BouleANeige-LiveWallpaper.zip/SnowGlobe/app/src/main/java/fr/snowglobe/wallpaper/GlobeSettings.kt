package fr.snowglobe.wallpaper

import android.content.SharedPreferences

/** Instantané immuable des réglages, relu à chaque modification dans l'écran de paramètres. */
data class GlobeSettings(
    val snowCount: Int,
    val petalCount: Int,
    val sparkleCount: Int,
    val shakeSensitivity: Float,
    val particleSpeed: Float,
    val gravityStrength: Float,
    val maxFps: Int,
    val sceneMode: String,
    val selectiveColor: Boolean,
    val colorThreshold: Float,
    val sceneScale: Float,
    val sceneOffset: Float,
    val baseStyle: String,
    val movingReflections: Boolean,
    val tapToShake: Boolean,
    val batterySaver: Boolean,
) {
    val isFillMode get() = sceneMode == "fill"

    companion object {
        const val KEY_IMAGE_VERSION = "image_version"

        /** Clés qui imposent de recharger / retraiter l'image source. */
        val IMAGE_KEYS = setOf(KEY_IMAGE_VERSION, "selective_color", "color_threshold")

        /** Clés qui imposent de reconstruire les calques statiques. */
        val LAYOUT_KEYS = setOf("scene_mode", "scene_scale", "scene_offset", "base_style")

        /** Toutes les clés gérées (utile pour la réinitialisation). */
        val ALL_KEYS = listOf(
            "snow_count", "petal_count", "sparkle_count", "shake_sensitivity", "particle_speed",
            "gravity_strength", "max_fps", "scene_mode", "selective_color", "color_threshold",
            "scene_scale", "scene_offset", "base_style", "moving_reflections", "tap_to_shake",
            "battery_saver",
        )

        fun load(p: SharedPreferences) = GlobeSettings(
            snowCount = p.getInt("snow_count", 260),
            petalCount = p.getInt("petal_count", 45),
            sparkleCount = p.getInt("sparkle_count", 30),
            shakeSensitivity = p.getInt("shake_sensitivity", 100) / 100f,
            particleSpeed = p.getInt("particle_speed", 100) / 100f,
            gravityStrength = p.getInt("gravity_strength", 100) / 100f,
            maxFps = p.getString("max_fps", "60")?.toIntOrNull() ?: 60,
            sceneMode = p.getString("scene_mode", "cutout") ?: "cutout",
            selectiveColor = p.getBoolean("selective_color", true),
            colorThreshold = p.getInt("color_threshold", 35) / 100f,
            sceneScale = p.getInt("scene_scale", 85) / 100f,
            sceneOffset = (p.getInt("scene_offset", 30) - 30) / 100f,
            baseStyle = p.getString("base_style", "metal") ?: "metal",
            movingReflections = p.getBoolean("moving_reflections", true),
            tapToShake = p.getBoolean("tap_to_shake", true),
            batterySaver = p.getBoolean("battery_saver", true),
        )
    }
}
