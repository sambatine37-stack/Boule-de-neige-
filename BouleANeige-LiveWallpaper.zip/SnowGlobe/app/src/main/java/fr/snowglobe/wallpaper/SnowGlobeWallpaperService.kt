package fr.snowglobe.wallpaper

import android.app.WallpaperManager
import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import androidx.preference.PreferenceManager
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.min

class SnowGlobeWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = GlobeEngine()

    private inner class GlobeEngine : Engine(),
        Choreographer.FrameCallback,
        SharedPreferences.OnSharedPreferenceChangeListener {

        private val ctx = this@SnowGlobeWallpaperService
        private val prefs = PreferenceManager.getDefaultSharedPreferences(ctx)
        private var settings = GlobeSettings.load(prefs)
        private val particles = ParticleSystem()
        private val renderer = GlobeRenderer()
        private val sensor = MotionSensor(ctx) { wake() }
        private val mainHandler = Handler(Looper.getMainLooper())
        private val loader: ExecutorService = Executors.newSingleThreadExecutor()

        private var sceneImage: SceneImage.Loaded? = null
        private var loadToken = 0
        private var surfaceW = 0
        private var surfaceH = 0
        private var visible = false
        private var looping = false
        private var destroyed = false
        private var useHardwareCanvas = true
        private var lastFrameNanos = 0L
        private var settledTime = 0f
        private var quietTime = 0f
        private var pendingTapShake = 0f

        private val palette get() = sceneImage?.palette ?: SceneImage.DEFAULT_PALETTE

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(this)
            sensor.shakeSensitivity = settings.shakeSensitivity
            particles.floorY = floorFor(settings)
            loadScene()
        }

        override fun onDestroy() {
            destroyed = true
            stopLoop()
            sensor.stop()
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            loader.shutdownNow()
            renderer.release()
            sceneImage?.bitmap?.recycle()
            sceneImage = null
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceW = width
            surfaceH = height
            sensor.updateRotation()
            rebuildLayout()
            if (!particles.matches(settings)) particles.configure(settings, palette)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            stopLoop()
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) {
                sensor.start()
                wake()
            } else {
                // Fond d'écran caché (appli plein écran, écran éteint) : plus aucun calcul ni capteur.
                stopLoop()
                sensor.stop()
            }
        }

        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean,
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP && settings.tapToShake &&
                renderer.isInsideGlobe(x.toFloat(), y.toFloat())
            ) {
                pendingTapShake += 1.2f
                wake()
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        override fun onSharedPreferenceChanged(p: SharedPreferences?, key: String?) {
            settings = GlobeSettings.load(prefs)
            sensor.shakeSensitivity = settings.shakeSensitivity
            particles.floorY = floorFor(settings)
            when {
                key == null || key in GlobeSettings.IMAGE_KEYS -> loadScene()
                key in GlobeSettings.LAYOUT_KEYS -> rebuildLayout()
            }
            if (!particles.matches(settings)) particles.configure(settings, palette)
            if (visible) wake() else drawFrame()
        }

        // ------------------------------------------------------------ chargement / mise en page

        private fun floorFor(s: GlobeSettings) =
            if (s.isFillMode) ParticleSystem.FLOOR_FILL else ParticleSystem.FLOOR_CUTOUT

        private fun loadScene() {
            val token = ++loadToken
            val s = settings
            val appCtx = ctx.applicationContext
            try {
                loader.execute {
                    val loaded = try {
                        SceneImage.load(appCtx, 1600, s.selectiveColor, s.colorThreshold)
                    } catch (t: Throwable) {
                        null
                    }
                    mainHandler.post {
                        if (destroyed || token != loadToken) {
                            loaded?.bitmap?.recycle()
                            return@post
                        }
                        val old = sceneImage
                        sceneImage = loaded
                        rebuildLayout()
                        old?.bitmap?.recycle()
                        particles.recolor(palette)
                        if (visible) wake() else drawFrame()
                    }
                }
            } catch (e: Exception) {
                // exécuteur arrêté : moteur en cours de destruction
            }
        }

        private fun rebuildLayout() {
            if (surfaceW <= 0 || surfaceH <= 0) return
            renderer.layout(surfaceW, surfaceH, settings, sceneImage?.bitmap)
        }

        // ------------------------------------------------------------ boucle d'animation

        /** Relance l'animation (appelé par les capteurs, un toucher ou un réglage). */
        private fun wake() {
            quietTime = 0f
            settledTime = 0f
            if (!visible || looping || destroyed) return
            looping = true
            lastFrameNanos = 0L
            sensor.setLowPower(false)
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun stopLoop() {
            looping = false
            Choreographer.getInstance().removeFrameCallback(this)
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!looping) return

            val fps = when {
                settledTime > 3f -> min(settings.maxFps, 20)
                quietTime > 8f -> min(settings.maxFps, 30)
                else -> settings.maxFps
            }
            val minInterval = 1_000_000_000L / fps
            if (lastFrameNanos != 0L && frameTimeNanos - lastFrameNanos < minInterval - 2_000_000L) {
                Choreographer.getInstance().postFrameCallback(this)
                return
            }
            val dt = if (lastFrameNanos == 0L) 1f / 60f
            else ((frameTimeNanos - lastFrameNanos) / 1e9f).coerceIn(0f, 0.05f)
            lastFrameNanos = frameTimeNanos

            val shake = sensor.consumeShake() + pendingTapShake
            pendingTapShake = 0f
            particles.step(
                dt, sensor.gravityX, sensor.gravityY, sensor.sloshX, sensor.sloshY,
                sensor.gyroZ, shake, settings,
            )
            drawFrame()

            quietTime += dt
            settledTime = if (particles.isSettled()) settledTime + dt else 0f

            if (settings.batterySaver && settledTime > 1.5f) {
                // Tout est retombé : on s'endort jusqu'au prochain mouvement significatif.
                looping = false
                sensor.setLowPower(true)
                return
            }
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun drawFrame() {
            if (surfaceW <= 0 || destroyed) return
            val holder = surfaceHolder
            val canvas = lockCanvas(holder) ?: return
            try {
                renderer.draw(canvas, particles, sensor.gravityX, sensor.gravityY, settings)
            } finally {
                try {
                    holder.unlockCanvasAndPost(canvas)
                } catch (e: IllegalStateException) {
                    // surface détruite entre-temps
                }
            }
        }

        private fun lockCanvas(holder: SurfaceHolder): Canvas? {
            if (useHardwareCanvas) {
                try {
                    return holder.lockHardwareCanvas()
                } catch (e: Exception) {
                    useHardwareCanvas = false   // certains appareils : repli sur le rendu logiciel
                }
            }
            return try { holder.lockCanvas() } catch (e: Exception) { null }
        }
    }
}
