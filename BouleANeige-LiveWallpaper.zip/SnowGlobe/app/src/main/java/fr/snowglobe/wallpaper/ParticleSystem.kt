package fr.snowglobe.wallpaper

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Moteur de particules dans un repère normalisé : centre de la boule = (0,0), rayon = 1, y vers le bas.
 *
 * Modèle « particules dans un liquide » :
 *  - gravité apparente (inclinaison) x facteur de chute propre à chaque type (flottabilité) ;
 *  - traînée visqueuse vers la vitesse locale du liquide (vitesse limite -> chute lente et douce) ;
 *  - le liquide possède un écoulement global, un tourbillon (alimenté par le gyroscope et les secousses)
 *    et une turbulence qui s'amortit en quelques secondes ;
 *  - collisions avec la paroi sphérique et le sol de neige (rebond amorti, frottement).
 *
 * Stockage en tableaux (structure-of-arrays) : aucune allocation par image -> pas de ramasse-miettes.
 */
class ParticleSystem {

    companion object {
        const val SNOW = 0
        const val PETAL = 1
        const val SPARKLE = 2

        const val FLOOR_CUTOUT = 0.62f
        const val FLOOR_FILL = 0.70f

        private const val BASE_ACC = 0.55f      // accélération (rayons/s²) pour 1 g
        private const val RESTITUTION = 0.18f   // rebonds très amortis par le liquide
        private const val WALL = 0.985f
    }

    var count = 0; private set
    var x = FloatArray(0); private set
    var y = FloatArray(0); private set
    var size = FloatArray(0); private set
    var angle = FloatArray(0); private set     // radians
    var phase = FloatArray(0); private set
    var type = IntArray(0); private set
    var color = IntArray(0); private set
    var front = BooleanArray(0); private set
    var time = 0f; private set

    var floorY = FLOOR_CUTOUT

    private var vx = FloatArray(0)
    private var vy = FloatArray(0)
    private var spin = FloatArray(0)

    private var nSnow = 0
    private var nPetal = 0
    private var nSparkle = 0

    private var turbulence = 0f
    private var flowX = 0f
    private var flowY = 0f
    private var swirl = 0f
    private var maxSpeed2 = 0f

    private val rnd = Random(System.nanoTime())

    fun matches(s: GlobeSettings) =
        count > 0 && nSnow == s.snowCount && nPetal == s.petalCount && nSparkle == s.sparkleCount

    fun configure(s: GlobeSettings, palette: IntArray) {
        nSnow = s.snowCount
        nPetal = s.petalCount
        nSparkle = s.sparkleCount
        count = nSnow + nPetal + nSparkle

        x = FloatArray(count); y = FloatArray(count)
        vx = FloatArray(count); vy = FloatArray(count)
        size = FloatArray(count); angle = FloatArray(count)
        spin = FloatArray(count); phase = FloatArray(count)
        type = IntArray(count); color = IntArray(count)
        front = BooleanArray(count)

        for (i in 0 until count) {
            val t = when {
                i < nSnow -> SNOW
                i < nSnow + nPetal -> PETAL
                else -> SPARKLE
            }
            type[i] = t
            size[i] = when (t) {
                SNOW -> rnd.range(0.005f, 0.014f)
                PETAL -> rnd.range(0.016f, 0.028f)
                else -> rnd.range(0.008f, 0.016f)
            }
            front[i] = rnd.nextFloat() > 0.35f
            phase[i] = rnd.nextFloat() * 6.2832f
            spin[i] = rnd.range(-3f, 3f)
            angle[i] = rnd.nextFloat() * 6.2832f
            color[i] = when (t) {
                PETAL -> palette[rnd.nextInt(palette.size)]
                SPARKLE -> 0xFFFFF1C9.toInt()
                else -> 0xFFFFFFFF.toInt()
            }
            placeRandom(i)
        }
        turbulence = 0.6f   // petit tourbillon à l'apparition
    }

    fun recolor(palette: IntArray) {
        for (i in 0 until count) if (type[i] == PETAL) color[i] = palette[rnd.nextInt(palette.size)]
    }

    private fun placeRandom(i: Int) {
        var px: Float
        var py: Float
        do {
            val r = sqrt(rnd.nextFloat()) * 0.92f
            val a = rnd.nextFloat() * 6.2832f
            px = r * cos(a)
            py = r * sin(a)
        } while (py > floorY - 0.05f)
        x[i] = px; y[i] = py
        vx[i] = 0f; vy[i] = 0f
    }

    /**
     * @param gX,gY gravité apparente lente (g)   @param sX,sY à-coups (g)
     * @param gyroZ rotation (rad/s)              @param shake énergie de secousse accumulée
     */
    fun step(
        dtReal: Float, gX: Float, gY: Float, sX: Float, sY: Float,
        gyroZ: Float, shake: Float, s: GlobeSettings,
    ) {
        val h = (dtReal * s.particleSpeed).coerceIn(0f, 0.06f)
        if (h <= 0f || count == 0) return
        time += h

        // ---- état du liquide ----
        val sens = s.shakeSensitivity
        flowX = flowX * exp(-h / 0.8f) + sX * 5f * sens * h
        flowY = flowY * exp(-h / 0.8f) + sY * 5f * sens * h
        swirl = swirl * exp(-h / 2.2f) + gyroZ * 1.2f * sens * h
        if (shake > 0f) {
            turbulence += shake * 1.4f
            swirl += (if (rnd.nextBoolean()) 1f else -1f) * shake * 1.2f
        }
        turbulence = (turbulence * exp(-h / 1.8f)).coerceAtMost(3.5f)
        swirl = swirl.coerceIn(-6f, 6f)
        flowX = flowX.coerceIn(-2f, 2f)
        flowY = flowY.coerceIn(-2f, 2f)

        val gAx = gX * s.gravityStrength * BASE_ACC
        val gAy = gY * s.gravityStrength * BASE_ACC
        val t1 = time * 1.3f
        val t2 = time * 0.9f
        val turb = turbulence * 0.45f
        val floor0 = floorY
        var maxV2 = 0f

        for (i in 0 until count) {
            val tp = type[i]
            val sink: Float
            val drag: Float
            when (tp) {
                SNOW -> { sink = 1f; drag = 3.2f }
                PETAL -> { sink = 1.25f; drag = 2.4f }
                else -> { sink = 0.45f; drag = 2.0f }
            }
            val px = x[i]
            val py = y[i]
            var pvx = vx[i]
            var pvy = vy[i]

            // vitesse locale du liquide : écoulement + tourbillon (sens horaire si swirl > 0) + turbulence
            var ux = flowX - swirl * py
            var uy = flowY + swirl * px
            if (turb > 0.0005f) {
                val ph = phase[i] * 0.15f
                ux += turb * (sin(py * 4.3f + t1 + ph) + 0.6f * sin(px * 7.1f - t2 * 1.7f))
                uy += turb * (cos(px * 3.9f - t2 + ph) + 0.6f * cos(py * 6.7f + t1 * 1.4f))
            }

            var ax = gAx * sink + (ux - pvx) * drag
            var ay = gAy * sink + (uy - pvy) * drag
            if (tp == PETAL) {
                // portance oscillante perpendiculaire au mouvement : effet « feuille morte »
                val f = sin(time * 3.1f + phase[i]) * 1.6f
                ax += -pvy * f
                ay += pvx * f
            }

            pvx += ax * h
            pvy += ay * h
            var nx = px + pvx * h
            var ny = py + pvy * h
            val m = size[i]

            // sol
            val floor = floor0 - m * 0.6f
            if (ny > floor) {
                ny = floor
                if (pvy > 0f) pvy = -pvy * RESTITUTION
                pvx *= 0.92f
                if (pvx * pvx + pvy * pvy < 0.03f * 0.03f) { pvx = 0f; pvy = 0f }
            }
            // paroi sphérique
            val lim = WALL - m
            val d2 = nx * nx + ny * ny
            if (d2 > lim * lim) {
                val d = sqrt(d2)
                val nX = nx / d
                val nY = ny / d
                nx = nX * lim
                ny = nY * lim
                val vn = pvx * nX + pvy * nY
                if (vn > 0f) {
                    pvx -= (1f + RESTITUTION) * vn * nX
                    pvy -= (1f + RESTITUTION) * vn * nY
                }
                // frottement contre le verre : la neige ne glisse pas indéfiniment
                pvx *= 0.90f
                pvy *= 0.90f
                // frottement statique : en dessous d'une petite vitesse, la particule « colle » au verre
                if (pvx * pvx + pvy * pvy < 0.04f * 0.04f) { pvx = 0f; pvy = 0f }
                if (ny > floor) {   // coin sol/paroi
                    ny = floor
                    val maxX = sqrt((lim * lim - ny * ny).coerceAtLeast(0f))
                    nx = nx.coerceIn(-maxX, maxX)
                }
            }

            x[i] = nx; y[i] = ny
            vx[i] = pvx; vy[i] = pvy
            val v2 = pvx * pvx + pvy * pvy
            if (v2 > maxV2) maxV2 = v2
            if (tp == PETAL) angle[i] += spin[i] * (0.2f + sqrt(v2) * 6f) * h
        }
        maxSpeed2 = maxV2
    }

    /** Vrai quand plus rien ne bouge visiblement : l'animation peut s'endormir. */
    fun isSettled(): Boolean =
        maxSpeed2 < 0.02f * 0.02f && turbulence < 0.03f &&
            abs(swirl) < 0.02f && abs(flowX) + abs(flowY) < 0.01f

    private fun Random.range(a: Float, b: Float) = a + nextFloat() * (b - a)
}
