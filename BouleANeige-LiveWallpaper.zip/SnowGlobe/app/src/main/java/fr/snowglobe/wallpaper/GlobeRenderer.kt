package fr.snowglobe.wallpaper

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Rendu Canvas accéléré matériellement.
 *
 * Tout ce qui est immobile (fond, intérieur de la boule, sol, image, verre, socle) est
 * précalculé UNE fois dans des bitmaps à chaque changement de taille / réglage.
 * Par image, on ne dessine que : 5 bitmaps + les particules + les reflets mobiles.
 *
 * Ordre des calques :
 *   fond -> particules arrière -> personnage -> particules avant -> verre -> reflets -> socle
 */
class GlobeRenderer {

    var cx = 0f; private set
    var cy = 0f; private set
    var radius = 0f; private set

    private var background: Bitmap? = null
    private var scene: Bitmap? = null
    private var glass: Bitmap? = null
    private var base: Bitmap? = null
    private var softSprite: Bitmap? = null
    private var glowSprite: Bitmap? = null
    private var glassPad = 0f
    private var baseLeft = 0f
    private var baseTop = 0f

    private val globePath = Path()
    private val tmpRect = RectF()
    private val arcRect = RectF()

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val snowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val petalPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
    }
    private val highlightPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 120 }
    private val glintPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 170 }
    private val crescentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0x66FFFFFF
    }

    fun isInsideGlobe(x: Float, y: Float) = hypot(x - cx, y - cy) < radius

    fun layout(width: Int, height: Int, s: GlobeSettings, source: Bitmap?) {
        release()
        val w = width.toFloat()
        val h = height.toFloat()
        radius = min(w * 0.45f, h * 0.30f)
        cx = w / 2f
        cy = h * 0.45f
        globePath.reset()
        globePath.addCircle(cx, cy, radius * 0.995f, Path.Direction.CW)
        crescentPaint.strokeWidth = radius * 0.03f

        softSprite = makeSprite(
            intArrayOf(0xFFFFFFFF.toInt(), 0x80FFFFFF.toInt(), 0x00FFFFFF),
            floatArrayOf(0f, 0.45f, 1f),
        )
        glowSprite = makeSprite(
            intArrayOf(0xFFFFFFFF.toInt(), 0xCCFFF4D6.toInt(), 0x33FFE7A8, 0x00000000),
            floatArrayOf(0f, 0.15f, 0.45f, 1f),
        )
        background = buildBackground(width, height, s)
        scene = buildScene(s, source)
        glass = buildGlass()
        base = buildBase(s)
    }

    fun release() {
        listOf(background, scene, glass, base, softSprite, glowSprite).forEach { it?.recycle() }
        background = null; scene = null; glass = null; base = null; softSprite = null; glowSprite = null
    }

    // ------------------------------------------------------------------ rendu par image

    fun draw(c: Canvas, ps: ParticleSystem, gX: Float, gY: Float, s: GlobeSettings) {
        val bg = background
        if (bg == null) { c.drawColor(Color.BLACK); return }
        c.drawBitmap(bg, 0f, 0f, null)

        val allFront = s.isFillMode   // en plein cadre, l'image est opaque : tout passe devant
        if (!allFront) drawParticles(c, ps, front = false, allFront = false)
        scene?.let { c.drawBitmap(it, cx - radius, cy - radius, bitmapPaint) }
        drawParticles(c, ps, front = true, allFront = allFront)
        glass?.let { c.drawBitmap(it, cx - radius - glassPad, cy - radius - glassPad, null) }
        drawHighlights(c, gX, gY, s.movingReflections)
        base?.let { c.drawBitmap(it, baseLeft, baseTop, null) }
    }

    private fun drawParticles(c: Canvas, ps: ParticleSystem, front: Boolean, allFront: Boolean) {
        val r = radius
        val glow = glowSprite ?: return
        val t = ps.time
        for (i in 0 until ps.count) {
            val isFront = allFront || ps.front[i]
            if (isFront != front) continue
            val px = cx + ps.x[i] * r
            val py = cy + ps.y[i] * r
            val sz = ps.size[i] * r * (if (isFront) 1f else 0.75f)
            when (ps.type[i]) {
                ParticleSystem.SNOW -> {
                    snowPaint.alpha = if (isFront) 235 else 140
                    c.drawCircle(px, py, sz, snowPaint)
                }
                ParticleSystem.PETAL -> {
                    petalPaint.color = ps.color[i]
                    petalPaint.alpha = if (isFront) 255 else 170
                    val a = ps.angle[i]
                    val flip = 0.4f + 0.6f * kotlin.math.abs(cos(a * 1.7f + ps.phase[i]))
                    c.save()
                    c.translate(px, py)
                    c.rotate(Math.toDegrees(a.toDouble()).toFloat())
                    tmpRect.set(-sz, -sz * 0.55f * flip, sz, sz * 0.55f * flip)
                    c.drawOval(tmpRect, petalPaint)
                    c.restore()
                }
                else -> {
                    val tw = 0.55f + 0.45f * sin(t * 4f + ps.phase[i])
                    glowPaint.alpha = (tw * (if (isFront) 255 else 150)).toInt()
                    val gs = sz * 3f
                    tmpRect.set(px - gs, py - gs, px + gs, py + gs)
                    c.drawBitmap(glow, null, tmpRect, glowPaint)
                }
            }
        }
    }

    private fun drawHighlights(c: Canvas, gX: Float, gY: Float, moving: Boolean) {
        val sprite = softSprite ?: return
        val r = radius
        // La source de lumière reste fixe « dans la pièce » : le reflet glisse quand on incline.
        val ox = if (moving) (-gX * 0.08f * r).coerceIn(-0.1f * r, 0.1f * r) else 0f
        val oy = if (moving) ((0.8f - gY) * 0.05f * r).coerceIn(-0.06f * r, 0.06f * r) else 0f

        c.save()
        c.clipPath(globePath)

        c.save()
        c.translate(cx - 0.42f * r + ox, cy - 0.50f * r + oy)
        c.rotate(-35f)
        tmpRect.set(-0.36f * r, -0.17f * r, 0.36f * r, 0.17f * r)
        c.drawBitmap(sprite, null, tmpRect, highlightPaint)
        c.restore()

        val k = 0.6f
        arcRect.set(cx - 0.88f * r + ox * k, cy - 0.88f * r + oy * k, cx + 0.88f * r + ox * k, cy + 0.88f * r + oy * k)
        c.drawArc(arcRect, 200f, 55f, false, crescentPaint)

        val gxp = cx + 0.58f * r - ox * 0.5f
        val gyp = cy + 0.30f * r - oy * 0.5f
        tmpRect.set(gxp - 0.05f * r, gyp - 0.05f * r, gxp + 0.05f * r, gyp + 0.05f * r)
        c.drawBitmap(sprite, null, tmpRect, glintPaint)
        c.restore()
    }

    // ------------------------------------------------------------------ calques statiques

    private fun buildBackground(w: Int, h: Int, s: GlobeSettings): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = radius

        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF1B1B1E.toInt(), 0xFF050506.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)

        p.shader = RadialGradient(cx, cy, r * 1.9f, 0x2EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.9f, p)

        // ombre portée du socle
        val shadowY = cy + 1.40f * r
        c.save()
        c.translate(cx, shadowY)
        c.scale(1f, 0.12f)
        p.shader = RadialGradient(0f, 0f, r * 1.2f, 0xAA000000.toInt(), 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, r * 1.2f, p)
        c.restore()

        // intérieur de la boule : décor minimaliste en niveaux de gris
        c.save()
        c.clipPath(globePath)
        p.shader = RadialGradient(
            cx, cy - 0.3f * r, r * 1.3f,
            intArrayOf(0xFF3A3A3D.toInt(), 0xFF1A1A1C.toInt(), 0xFF0A0A0B.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawCircle(cx, cy, r, p)

        if (!s.isFillMode) {
            val floorTop = cy + ParticleSystem.FLOOR_CUTOUT * r
            p.shader = LinearGradient(
                0f, floorTop, 0f, cy + r,
                intArrayOf(0xFFE4E4E6.toInt(), 0xFFA6A6AA.toInt(), 0xFF5E5E62.toInt()),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP,
            )
            c.drawRect(cx - r, floorTop, cx + r, cy + r, p)
            p.shader = null
            p.color = 0xFFF2F2F4.toInt()
            val half = kotlin.math.sqrt(1f - ParticleSystem.FLOOR_CUTOUT * ParticleSystem.FLOOR_CUTOUT) * r
            c.drawOval(cx - half, floorTop - 0.035f * r, cx + half, floorTop + 0.035f * r, p)
        }
        c.restore()
        return bmp
    }

    private fun buildScene(s: GlobeSettings, src: Bitmap?): Bitmap {
        val r = radius
        val size = max(2, (r * 2f).toInt())
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path().apply { addCircle(r, r, r * 0.995f, Path.Direction.CW) }
        c.clipPath(clip)

        if (src == null) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x99FFFFFF.toInt()
                textAlign = Paint.Align.CENTER
                textSize = r * 0.075f
            }
            c.drawText("Ouvrez les réglages", r, r - tp.textSize * 0.3f, tp)
            c.drawText("et choisissez votre image", r, r + tp.textSize * 1.0f, tp)
            return bmp
        }

        val aspect = src.width.toFloat() / src.height
        val dst: RectF
        if (s.isFillMode) {
            val zoom = 0.5f + s.sceneScale * 0.6f
            val side = 2f * r * zoom
            val dw: Float
            val dh: Float
            if (aspect >= 1f) { dh = side; dw = side * aspect } else { dw = side; dh = side / aspect }
            val ccy = r + s.sceneOffset * r
            dst = RectF(r - dw / 2f, ccy - dh / 2f, r + dw / 2f, ccy + dh / 2f)
        } else {
            var th = s.sceneScale * 1.3f * r
            var tw = th * aspect
            if (tw > 1.75f * r) { tw = 1.75f * r; th = tw / aspect }
            val bottom = r + (ParticleSystem.FLOOR_CUTOUT + 0.04f + s.sceneOffset) * r
            dst = RectF(r - tw / 2f, bottom - th, r + tw / 2f, bottom)

            // ombre douce sous les pieds
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
            val sw = tw * 0.32f
            c.save()
            c.translate(r, bottom - 0.01f * r)
            c.scale(1f, 0.16f)
            shadow.shader = RadialGradient(0f, 0f, sw, 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
            c.drawCircle(0f, 0f, sw, shadow)
            c.restore()
        }
        c.drawBitmap(src, null, dst, bitmapPaint)
        return bmp
    }

    private fun buildGlass(): Bitmap {
        val r = radius
        glassPad = r * 0.04f
        val size = max(2, (2f * (r + glassPad)).toInt())
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val o = r + glassPad
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // assombrissement des bords (épaisseur du verre / réfraction)
        p.shader = RadialGradient(
            o, o, r, intArrayOf(0x00000000, 0x00000000, 0x66000000),
            floatArrayOf(0f, 0.80f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawCircle(o, o, r, p)
        // liseré lumineux (effet de Fresnel)
        p.shader = RadialGradient(
            o, o, r, intArrayOf(0x00FFFFFF, 0x00FFFFFF, 0x45FFFFFF, 0x14FFFFFF),
            floatArrayOf(0f, 0.90f, 0.985f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawCircle(o, o, r, p)
        p.shader = null

        // reflet secondaire en bas à droite
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.022f
        p.color = 0x30FFFFFF
        c.drawArc(o - 0.92f * r, o - 0.92f * r, o + 0.92f * r, o + 0.92f * r, 15f, 60f, false, p)

        // contour fin
        p.strokeWidth = max(1.5f, r * 0.006f)
        p.color = 0x55FFFFFF
        c.drawCircle(o, o, r, p)
        return bmp
    }

    private fun buildBase(s: GlobeSettings): Bitmap {
        val r = radius
        baseLeft = cx - 1.0f * r
        baseTop = cy + 0.70f * r
        val bw = max(2, (2.0f * r).toInt())
        val bh = max(2, (0.80f * r).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(-baseLeft, -baseTop)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        val metal = s.baseStyle != "black"
        val colors = if (metal) intArrayOf(
            0xFF2B2B2E.toInt(), 0xFF6D6D72.toInt(), 0xFFD8D8DC.toInt(),
            0xFF8A8A90.toInt(), 0xFF3A3A3E.toInt(), 0xFF1C1C1F.toInt(),
        ) else intArrayOf(
            0xFF050505.toInt(), 0xFF1E1E20.toInt(), 0xFF46464A.toInt(),
            0xFF18181A.toInt(), 0xFF0A0A0B.toInt(), 0xFF030303.toInt(),
        )
        val stops = floatArrayOf(0f, 0.22f, 0.42f, 0.6f, 0.82f, 1f)

        val top = cy + 0.80f * r
        val bottom = cy + 1.36f * r
        val topHalf = 0.66f * r
        val botHalf = 0.92f * r

        val body = Path().apply {
            moveTo(cx - topHalf, top)
            lineTo(cx + topHalf, top)
            lineTo(cx + botHalf, bottom - 0.06f * r)
            quadTo(cx, bottom + 0.07f * r, cx - botHalf, bottom - 0.06f * r)
            close()
        }
        p.shader = LinearGradient(cx - botHalf, 0f, cx + botHalf, 0f, colors, stops, Shader.TileMode.CLAMP)
        c.drawPath(body, p)

        // filet décoratif
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.012f
        p.color = if (metal) 0x55FFFFFF else 0x66B89B5E
        val lineY = bottom - 0.20f * r
        val lh = topHalf + (botHalf - topHalf) * ((lineY - top) / (bottom - top))
        val accent = Path().apply {
            moveTo(cx - lh, lineY)
            quadTo(cx, lineY + 0.07f * r, cx + lh, lineY)
        }
        c.drawPath(accent, p)
        p.style = Paint.Style.FILL

        // collerette (là où le verre s'emboîte)
        p.shader = LinearGradient(cx - topHalf, 0f, cx + topHalf, 0f, colors, stops, Shader.TileMode.CLAMP)
        c.drawOval(cx - topHalf - 0.04f * r, top - 0.08f * r, cx + topHalf + 0.04f * r, top + 0.08f * r, p)
        p.shader = null
        p.color = 0x22FFFFFF
        c.drawOval(cx - topHalf, top - 0.05f * r, cx + topHalf, top + 0.03f * r, p)
        return bmp
    }

    private fun makeSprite(colors: IntArray, stops: FloatArray): Bitmap {
        val n = 64
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(n / 2f, n / 2f, n / 2f, colors, stops, Shader.TileMode.CLAMP)
        c.drawCircle(n / 2f, n / 2f, n / 2f, p)
        return bmp
    }
}
