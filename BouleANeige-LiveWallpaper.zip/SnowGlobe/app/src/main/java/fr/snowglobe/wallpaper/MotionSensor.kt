package fr.snowglobe.wallpaper

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Lit l'accéléromètre et le gyroscope et les convertit dans le repère de l'écran
 * (x vers la droite, y vers le bas, unités : g).
 *
 * Physique : l'accéléromètre mesure la « force spécifique » f = a - g.
 * La gravité apparente ressentie par la neige dans le repère du téléphone vaut donc -f.
 *  - composante lente (filtre passe-bas)  -> direction de la gravité (inclinaison)
 *  - composante rapide (passe-haut)       -> à-coups / secousses qui mettent le liquide en mouvement
 */
class MotionSensor(
    context: Context,
    private val onSignificantMotion: () -> Unit,
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyroscope: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    /** Gravité apparente dans le plan de l'écran (en g). Par défaut : téléphone tenu droit. */
    var gravityX = 0f; private set
    var gravityY = 1f; private set

    /** Partie rapide de l'accélération (en g), déjà orientée comme une force sur le liquide. */
    var sloshX = 0f; private set
    var sloshY = 0f; private set

    /** Vitesse de rotation autour de l'axe perpendiculaire à l'écran (rad/s). */
    var gyroZ = 0f; private set

    var shakeSensitivity = 1f

    private var shakeAccumulator = 0f
    private var lpX = 0f
    private var lpY = 0f
    private var lpZ = 0f
    private var initialized = false
    private var lastWakeGX = 0f
    private var lastWakeGY = 1f
    private var rotation = Surface.ROTATION_0
    private var registered = false
    private var lowPower = false

    fun start() {
        if (registered) return
        updateRotation()
        register(SensorManager.SENSOR_DELAY_GAME)
        lowPower = false
    }

    fun stop() {
        if (!registered) return
        sensorManager.unregisterListener(this)
        registered = false
        initialized = false
        gyroZ = 0f
        sloshX = 0f
        sloshY = 0f
    }

    /** En pause (animation endormie) : on garde les capteurs mais à cadence réduite. */
    fun setLowPower(low: Boolean) {
        if (!registered || low == lowPower) return
        sensorManager.unregisterListener(this)
        register(if (low) SensorManager.SENSOR_DELAY_UI else SensorManager.SENSOR_DELAY_GAME)
        lowPower = low
    }

    fun updateRotation() {
        rotation = displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    }

    /** Énergie de secousse accumulée depuis le dernier appel (remise à zéro). */
    fun consumeShake(): Float {
        val s = shakeAccumulator
        shakeAccumulator = 0f
        return s
    }

    private fun register(rate: Int) {
        accelerometer?.let { sensorManager.registerListener(this, it, rate) }
        gyroscope?.let { sensorManager.registerListener(this, it, rate) }
        registered = true
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> handleAccelerometer(event.values)
            Sensor.TYPE_GYROSCOPE -> {
                gyroZ = event.values[2]
                if (abs(gyroZ) > 0.35f) onSignificantMotion()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun handleAccelerometer(v: FloatArray) {
        // Repère « naturel » du capteur -> repère de l'écran selon la rotation affichée.
        var ax = v[0]
        var ay = v[1]
        val az = v[2]
        when (rotation) {
            Surface.ROTATION_90 -> { val t = ax; ax = -ay; ay = t }
            Surface.ROTATION_180 -> { ax = -ax; ay = -ay }
            Surface.ROTATION_270 -> { val t = ax; ax = ay; ay = -t }
        }

        if (!initialized) {
            lpX = ax; lpY = ay; lpZ = az
            initialized = true
        }
        // Passe-bas (~0,2 s à 50 Hz) : sépare inclinaison lente et secousses.
        val k = if (lowPower) 0.35f else 0.1f
        lpX += (ax - lpX) * k
        lpY += (ay - lpY) * k
        lpZ += (az - lpZ) * k

        val g = SensorManager.GRAVITY_EARTH
        val hx = ax - lpX
        val hy = ay - lpY
        val hz = az - lpZ

        // y capteur vers le haut, y écran vers le bas -> signe inversé sur x uniquement.
        gravityX = -lpX / g
        gravityY = lpY / g
        sloshX = -hx / g
        sloshY = hy / g

        val jolt = sqrt(hx * hx + hy * hy + hz * hz) / g
        val threshold = 0.18f / shakeSensitivity.coerceAtLeast(0.1f)
        if (jolt > threshold) {
            shakeAccumulator += jolt - threshold
            onSignificantMotion()
        } else if (abs(gravityX - lastWakeGX) + abs(gravityY - lastWakeGY) > 0.03f) {
            lastWakeGX = gravityX
            lastWakeGY = gravityY
            onSignificantMotion()
        }
    }
}
