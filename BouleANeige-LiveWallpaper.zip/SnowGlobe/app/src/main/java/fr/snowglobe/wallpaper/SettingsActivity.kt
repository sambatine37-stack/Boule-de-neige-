package fr.snowglobe.wallpaper

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        // Sélecteur de fichiers système : aucune permission de stockage nécessaire.
        private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importImage(uri)
        }

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<Preference>("pick_image")?.setOnPreferenceClickListener {
                pickImage.launch(arrayOf("image/*"))
                true
            }
            findPreference<Preference>("clear_image")?.setOnPreferenceClickListener {
                SceneImage.file(requireContext()).delete()
                bumpImageVersion()
                toast("Image retirée")
                true
            }
            findPreference<Preference>("apply_wallpaper")?.setOnPreferenceClickListener {
                applyWallpaper()
                true
            }
            findPreference<Preference>("reset")?.setOnPreferenceClickListener {
                val editor = preferenceManager.sharedPreferences?.edit()
                GlobeSettings.ALL_KEYS.forEach { editor?.remove(it) }
                editor?.apply()
                activity?.recreate()
                true
            }
            updateImageSummary()
        }

        private fun importImage(uri: Uri) {
            val appCtx = requireContext().applicationContext
            Thread {
                val ok = SceneImage.import(appCtx, uri)
                activity?.runOnUiThread {
                    if (!isAdded) return@runOnUiThread
                    if (ok) {
                        bumpImageVersion()
                        toast("Image importée")
                    } else {
                        toast("Impossible de lire cette image")
                    }
                    updateImageSummary()
                }
            }.start()
        }

        private fun bumpImageVersion() {
            preferenceManager.sharedPreferences?.edit()
                ?.putLong(GlobeSettings.KEY_IMAGE_VERSION, System.currentTimeMillis())
                ?.apply()
            updateImageSummary()
        }

        private fun updateImageSummary() {
            findPreference<Preference>("pick_image")?.summary =
                if (SceneImage.exists(requireContext())) "Image chargée — touchez pour la remplacer"
                else "PNG détouré (fond transparent) conseillé"
        }

        private fun applyWallpaper() {
            val component = ComponentName(requireContext(), SnowGlobeWallpaperService::class.java)
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                try {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                } catch (e2: ActivityNotFoundException) {
                    toast("Ouvrez Paramètres > Fond d'écran > Fonds d'écran animés")
                }
            }
        }

        private fun toast(msg: String) =
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }
}
