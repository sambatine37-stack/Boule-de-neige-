# Boule à neige — fond d'écran animé Android

Live Wallpaper natif (Kotlin + `WallpaperService`), piloté par l'accéléromètre et le gyroscope.
100 % hors ligne, aucune dépendance payante, aucune permission requise.

## 1. Ce que fait l'application

- Boule en verre avec reflets (dont un reflet principal qui glisse quand on incline), socle métal ou noir.
- Votre image au centre, **immobile**, importée depuis la galerie (aucune régénération par IA).
- Option « noir et blanc sauf les couleurs vives » : les fleurs restent en couleur, le reste passe en gris.
- Neige, pétales (couleurs prélevées automatiquement dans le bouquet de votre image) et particules lumineuses.
- Inclinaison → la neige tombe dans le sens de la gravité réelle.
- Secousse → turbulence + tourbillon dans le liquide.
- Rotation du téléphone (gyroscope) → le liquide « traîne » et tourne.
- Toucher la boule → petite secousse (désactivable).
- Arrêt complet (rendu + capteurs) quand le fond d'écran n'est pas visible ; pause automatique quand tout est retombé.

## 2. Préparer l'image

Deux modes au choix dans les réglages :

**Personnage détouré (recommandé)** — un PNG avec fond transparent. Le personnage est posé sur un sol de neige ; les particules passent devant ET derrière lui (effet de profondeur). Les marges transparentes sont recadrées automatiquement.

Pour détourer gratuitement, au choix :
- Android 14+ / Pixel / Samsung : appui long sur le sujet dans Google Photos ou la Galerie → « Copier / Enregistrer le sujet ».
- PC : GIMP (Sélection floue + Masque de calque), ou Photopea dans le navigateur.
- Photo d'un pochoir sur un mur blanc : GIMP → Couleurs → Couleur vers alpha (blanc) donne un résultat très propre.

**Image entière** — n'importe quelle image : elle remplit la boule (recadrage centré). Aucune préparation.

Réglages fins : taille, position verticale, seuil de couleur conservée.

Remarque : l'œuvre de Banksy est protégée. Un usage personnel sur votre téléphone ne pose pas de souci, mais ne distribuez pas l'APK avec l'image intégrée. L'application ne contient aucune image, elle charge la vôtre.

## 3. Obtenir l'APK

### Option A — GitHub Actions (sans rien installer)
1. Créez un compte GitHub gratuit et un nouveau dépôt (privé si vous voulez).
2. Envoyez tout le contenu de ce dossier dans le dépôt (sur PC : « Add file → Upload files » puis glissez les fichiers et dossiers, y compris `.github/`).
3. Onglet **Actions** → workflow « Build APK » → il se lance tout seul (sinon « Run workflow »).
4. Après ~5 min, ouvrez l'exécution terminée → section **Artifacts** → téléchargez `boule-a-neige-apk` (zip contenant l'APK).

### Option B — Android Studio (PC)
1. Installez Android Studio (gratuit).
2. *File → Open* → choisissez ce dossier. Laissez la synchronisation Gradle se terminer (première fois : quelques minutes, Internet nécessaire pour télécharger les outils).
3. *Build → Build App Bundle(s) / APK(s) → Build APK(s)*.
4. APK : `app/build/outputs/apk/debug/app-debug.apk`.
   Ou branchez le téléphone (débogage USB activé) et cliquez ▶ Run.

### Option C — Ligne de commande
Avec le JDK 17 et le SDK Android (`ANDROID_HOME` défini) :
```
./gradlew assembleDebug        # Windows : gradlew.bat assembleDebug
```

## 4. Installer et activer
1. Copiez l'APK sur le téléphone et ouvrez-le. Autorisez « Installer des applis inconnues » pour le gestionnaire de fichiers ou le navigateur concerné.
2. Ouvrez l'appli **Boule à neige** → « Choisir l'image ».
3. « Définir comme fond d'écran » → Appliquer (écran d'accueil et/ou verrouillage selon le téléphone).

Les réglages sont aussi accessibles depuis le sélecteur de fond d'écran (bouton Paramètres).

## 5. Réglages disponibles
| Réglage | Effet |
|---|---|
| Quantité de neige / pétales / lumières | nombre de particules de chaque type |
| Sensibilité aux secousses | seuil de détection et force du tourbillon |
| Vitesse des particules | accélère ou ralentit toute la simulation |
| Intensité de la gravité | vitesse de chute selon l'inclinaison |
| Toucher pour secouer | tape sur la boule = mini-secousse |
| Socle | métal brossé / noir laqué |
| Reflets mobiles | le reflet suit l'inclinaison |
| Images/s max. | 30 (économe) ou 60 (fluide) |
| Économie de batterie | pause quand tout est retombé |

## 6. Architecture

```
SnowGlobeWallpaperService   Moteur : cycle de vie, visibilité, boucle Choreographer, cadence adaptative
 ├─ MotionSensor            Accéléromètre + gyroscope → gravité (passe-bas), à-coups (passe-haut), rotation
 ├─ ParticleSystem          Physique en repère normalisé (rayon = 1), tableaux sans allocation
 ├─ GlobeRenderer           Canvas matériel ; calques statiques précalculés en bitmaps
 └─ SceneImage              Import, EXIF, réduction, recadrage, couleur sélective, palette
SettingsActivity            Écran de réglages (AndroidX Preference) + sélecteur d'image
```

Physique : la neige subit la gravité apparente (inverse de la mesure de l'accéléromètre), une traînée visqueuse vers la vitesse locale du liquide (d'où une chute lente et douce), et le liquide a un écoulement, un tourbillon et une turbulence qui s'amortissent. Collisions avec la sphère et le sol, rebonds très amortis, frottement statique sur le verre.

Batterie : 0 calcul quand le fond est masqué ; capteurs désenregistrés ; passage à 30 i/s après 8 s sans mouvement, puis pause totale quand tout est posé (capteurs en cadence réduite, réveil instantané au moindre mouvement). Par image, seuls 5 bitmaps, les particules et 3 reflets sont dessinés.

## 7. Pistes d'évolution
- Passer en OpenGL ES 2 pour une vraie réfraction (léger effet loupe sur les bords du verre).
- Parallaxe selon le défilement des pages d'accueil (`onOffsetsChanged`).
- Accumulation visible de neige au sol après plusieurs secousses.

## Dépannage
- **Rien ne bouge** : vérifiez que l'économie d'énergie du téléphone ne bloque pas les capteurs ; touchez la boule pour tester.
- **Le toucher ne secoue pas** : certains lanceurs ne transmettent pas les tapes au fond d'écran ; les capteurs fonctionnent quand même.
- **Écran noir sur un appareil exotique** : l'appli repasse automatiquement en rendu logiciel si le rendu matériel échoue.
- **Android Studio propose de mettre à jour Gradle/AGP** : vous pouvez accepter.
